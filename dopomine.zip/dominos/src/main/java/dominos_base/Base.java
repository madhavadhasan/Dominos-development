package dominos_base;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Base {

	public static WebDriver driver;
	
	public static void browserLaunch(){
		
		driver = new ChromeDriver();
		
	}
	
	public static void geturl(String url) {
		driver.get(url);
		
	}
	
	public static void max() {
		driver.manage().window().maximize();
		
	}
	
	public static void implicitywait() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
	}
	
	
}
