package dominos_pom;

import org.openqa.selenium.By;

public class pomclass {

	public By ODERONLINE = By.id("landscape-mode");
	
	public By ADDRESS = By.xpath("//input[@class='srch-cnt-srch-inpt']");
	
	public By REMOVEALERT = By.xpath("//button[@onclick='moeRemoveBanner()']");
			
	public By LOCATION = By.xpath("//input[@placeholder='Enter Area / Locality']");
	
	public By LOCATIONCLICK = By.xpath("(//span[@class='lst-desc-main ellipsis'])[1]");
	
	public By MARGHERITA = By.xpath("(//button[@data-label='addTocart'])[46]");  
	
	public By REMOVECHESS = By.xpath("//button[@data-label='Add button']");
	
	public By ADD1 = By.xpath("(//div[@data-label='increase'])[3]");
	
	public By PEPPYPANEER = By.xpath("(//button[@data-label='addTocart'])[45]");
	
	public By ADD2 = By.xpath("(//div[@class='injectStyles-sc-1jy9bcf-0 gwKvJy'])[5]");
	
	public By VEGGPIZZ = By.xpath("(//button[@data-label='addTocart'])[54]");
	
	public By ADD3 = By.xpath("(//div[@class='injectStyles-sc-1jy9bcf-0 gwKvJy'])[6]");
	
	public By BEVERAGES = By.xpath("(//div[@data-label='Beverages'])[1]");
	
	public By PEPSI = By.xpath("(//button[@data-label='addTocart'])[67]");
	
	public By ADD4 = By.xpath("(//div[@data-label='increase'])[12]");
	
	public By REMOVEPIZZA = By.xpath("(//div[@class='injectStyles-sc-1jy9bcf-0 kYAlCU'])[1]");
	
	public By REMOVEPEPSI = By.xpath("(//div[@class='injectStyles-sc-1jy9bcf-0 kYAlCU'])[5]");
	
	public By CLICkCHECKOUT = By.xpath("//button[@data-label='miniCartCheckout']");
	
	
}
