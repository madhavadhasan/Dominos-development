package dominosRunner;

import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import dominos_base.Base;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;


@RunWith(Cucumber.class)
@CucumberOptions(features = "src\\test\\java\\dominosFeature\\Dominos.feature",glue = "dominosStepdefinition")

public class runner extends Base {

@BeforeClass

	public static void start() {
			browserLaunch();
	
}
	
}
