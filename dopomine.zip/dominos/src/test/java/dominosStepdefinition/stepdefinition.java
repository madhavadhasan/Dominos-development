package dominosStepdefinition;

import org.openqa.selenium.By;

import dominos_base.Base;
import dominos_pom.pomclass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepdefinition extends Base{

	pomclass Dom = new pomclass();
	
	
@Given("User launch the dominos web site url")
public void user_launch_the_dominos_web_site_url() {
	max();
	geturl("https://www.dominos.co.in/");
	
}


@When("user add the address")
public void user_add_the_address() throws InterruptedException {
Thread.sleep(5000);	
	driver.findElement(Dom.ODERONLINE).click();
Thread.sleep(5000);
	driver.findElement(Dom.ADDRESS).click();
	
}

@When("user add the location")
public void user_add_the_location() throws InterruptedException {
Thread.sleep(5000);
	  	driver.findElement(Dom.REMOVEALERT).click();
Thread.sleep(5000);
		driver.findElement(Dom.LOCATION).sendKeys("vellore new bus station");
Thread.sleep(5000);		
		driver.findElement(Dom.LOCATIONCLICK).click();
			
}

@Then("user add veg pizza margherita")
public void user_add_veg_pizza_margherita() throws InterruptedException {
 Thread.sleep(5000);  
		driver.findElement(Dom.MARGHERITA).click();
Thread.sleep(5000); 		
		driver.findElement(Dom.REMOVECHESS).click();
 Thread.sleep(5000); 
		driver.findElement(Dom.ADD1).click();
}

@Then("user add veg pizza peppy paneer")
public void user_add_veg_pizza_peppy_paneer() throws InterruptedException {
Thread.sleep(5000);
	driver.findElement(Dom.PEPPYPANEER).click();
	
	driver.findElement(Dom.ADD2).click();
  
}

@Then("user add veg pizza")
public void user_add_veg_pizza() throws InterruptedException {
Thread.sleep(5000);
	driver.findElement(Dom.VEGGPIZZ).click();

	driver.findElement(Dom.ADD3).click();
   
}

@Then("user add pepsi cooldrink")
public void user_add_pepsi_cooldrink() {
		driver.findElement(Dom.BEVERAGES).click();

		driver.findElement(Dom.PEPSI).click();

		driver.findElement(Dom.ADD4).click();
	
}


@Then("User remove Extra pizza")
public void user_remove_extra_pizza() throws InterruptedException {
Thread.sleep(5000);
	driver.findElement(Dom.REMOVEPIZZA).click();
	
}

@Then("User remove pepsi")
public void user_remove_pepsi() {
	driver.findElement(Dom.REMOVEPEPSI).click();
}

@Then("User click checkout")
public void user_click_checkout() {
	driver.findElement(Dom.CLICkCHECKOUT).click();
}
}
